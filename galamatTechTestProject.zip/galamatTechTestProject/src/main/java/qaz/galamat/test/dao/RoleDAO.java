package qaz.galamat.test.dao;

public interface RoleDAO {
}

package qaz.galamat.test.entity;

public class Comment {
}
